package RegistrationApp;

import javax.swing.JOptionPane;

public class RegistrationApp {
    public static String firstName;
    public static String lastName;
    public static String password;
    public static String username;
    public static String phoneNumber;

    // Store and retrieve user details (static access for simplicity in this project)
    public static void setFirstName(String name) { firstName = name; }
    public static String getFirstName() { return firstName; }

    public static void setLastName(String surname) { lastName = surname; }
    public static String getLastName() { return lastName; }

    public static void setUserName(String userName) { username = userName; }
    public static String getUserName() { return username; }

    public static void setPassword(String pass) { password = pass; }
    public static String getPassword() { return password; }

    public static void setPhoneNumber(String phone) { phoneNumber = phone; }
    public static String getPhoneNumber() { return phoneNumber; }

    // Application entry point: collects user input, validates it, and handles login attempts
    public static void main(String[] args) {
        setFirstName(JOptionPane.showInputDialog(null, "Please enter your first name:"));
        setLastName(JOptionPane.showInputDialog(null, "Please enter your last name:"));

        // Prompt for a username until the format is correct
        String usernameInput;
        do {
            usernameInput = JOptionPane.showInputDialog(null, "Enter username (≤5 chars and must contain '_'):");
            if (!RegistrationApp.isUsernameValid(usernameInput)) {
                JOptionPane.showMessageDialog(null,
                        "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.");
            }
        } while (!RegistrationApp.isUsernameValid(usernameInput));
        setUserName(usernameInput);

        // Prompt for a password until the strength requirements are met
        String passwordInput;
        do {
            passwordInput = JOptionPane.showInputDialog(null,
                    "Enter password (≥8 chars, must include: 1 capital, 1 number, 1 special character):");
            if (!RegistrationApp.isPasswordStrong(passwordInput)) {
                JOptionPane.showMessageDialog(null,
                        "Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
            }
        } while (!RegistrationApp.isPasswordStrong(passwordInput));
        setPassword(passwordInput);

        // Prompt for a valid South African phone number until the format is correct
        String phoneInput;
        do {
            phoneInput = JOptionPane.showInputDialog(null,
                    "Enter phone number (must start with +27 followed by 9 digits):\nExample: +27831234567");
            if (!RegistrationApp.isPhoneNumberValid(phoneInput)) {
                JOptionPane.showMessageDialog(null,
                        "Cell phone number incorrectly formatted or does not contain international code.");
            }
        } while (!RegistrationApp.isPhoneNumberValid(phoneInput));
        setPhoneNumber(phoneInput);

        // Run registration validation and show result
        RegistrationApp authenticator = new RegistrationApp();
        String registrationResult = authenticator.validateAndRegisterUser(getUserName(), getPassword(), getPhoneNumber());
        JOptionPane.showMessageDialog(null, registrationResult);

        // Login process: allow up to three attempts to authenticate
        boolean loginSuccessful = false;
        int attempts = 0;
        final int MAX_ATTEMPTS = 3;

        // Use the Login inner class for authentication
        Login login = new Login();

        while (!loginSuccessful && attempts < MAX_ATTEMPTS) {
            String enteredUsername = JOptionPane.showInputDialog("Enter username to login:");
            String enteredPassword = JOptionPane.showInputDialog("Enter password to login:");

            login.inputUsername(enteredUsername);
            login.inputPassword(enteredPassword);

            // FIXED LINE: check login.authenticate() instead of loginSuccessful.registrationResult()
            if (login.authenticate()) {
                JOptionPane.showMessageDialog(null, login.getLoginFeedback());
                loginSuccessful = true;
            } else {
                attempts++;
                JOptionPane.showMessageDialog(null,
                        "Login failed. Attempt " + attempts + " of " + MAX_ATTEMPTS
                                + "\nUsername or password incorrect, please try again.");
            }
        }

        // Block further login attempts if maximum retries are reached
        if (!loginSuccessful) {
            JOptionPane.showMessageDialog(null, "Maximum login attempts exceeded. Please try again later.");
        }
    }

    public String inputtedUsername;
    public String inputtedPassword;

    // Rule check for usernames:
    // Accepts only short identifiers (max 5 chars) that include an underscore.
    public static boolean isUsernameValid(String userName) {
        return userName != null && userName.contains("_") && userName.length() <= 5;
    }

    // Password policy enforcement:
    // A strong password must be at least 8 characters and contain
    // a capital letter, a numeric digit, and a non-alphanumeric symbol.
    public static boolean isPasswordStrong(String password) {
        if (password == null || password.length() < 8) return false;
        boolean hasDigit = false, hasUppercase = false, hasSpecial = false;
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasUppercase = true;
            if (Character.isDigit(c)) hasDigit = true;
            if (!Character.isLetterOrDigit(c)) hasSpecial = true;
        }
        return hasDigit && hasUppercase && hasSpecial;
    }

    // South African mobile number validation:
    // Must start with +27 and contain exactly nine numeric digits after it.
    public static boolean isPhoneNumberValid(String number) {
        return number != null && number.matches("^\\+27[0-9]{9}$");
    }

    // Registration workflow:
    // Ensures that username, password, and phone number all satisfy their rules.
    // Returns a feedback message indicating the first issue found, or success if all checks pass.
    public String validateAndRegisterUser(String username, String password, String phoneNumber) {
        boolean usernameIsValid = isUsernameValid(username);
        boolean passwordIsStrong = isPasswordStrong(password);
        boolean phoneIsValid = isPhoneNumberValid(phoneNumber);

        if (!usernameIsValid) {
            return "Username is not correctly formatted. Please ensure that your username contains an underscore and is no more than five characters in length.";
        } else if (!passwordIsStrong) {
            return "Password is not correctly formatted. Please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        } else if (!phoneIsValid) {
            return "Cell phone number is incorrectly formatted or does not contain the correct international code.";
        } else {
            return "Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.\nUser registered successfully.";
        }
    }

    // Stub methods (can be removed or implemented if needed)
    private void inputUsername(String enteredUsername) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    private void inputPassword(String enteredPassword) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    private Object getLoginFeedback() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    // Inner Login class handling authentication logic
    static class Login {

        private static String getUserName() {
            return RegistrationApp.getUserName();
        }

        private static String getPassword() {
            return RegistrationApp.getPassword();
        }

        private static String getFirstName() {
            return RegistrationApp.getFirstName();
        }

        private static String getLastName() {
            return RegistrationApp.getLastName();
        }

        private String inputtedUsername;
        private String inputtedPassword;

        // Rule check for usernames:
        // Accepts only short identifiers (max 5 chars) that include an underscore.
        public static boolean isUsernameValid(String userName) {
            return userName != null && userName.contains("_") && userName.length() <= 5;
        }

        // Password policy enforcement:
        // A strong password must be at least 8 characters and contain
        // a capital letter, a numeric digit, and a non-alphanumeric symbol.
        public static boolean isPasswordStrong(String password) {
            if (password == null || password.length() < 8) return false;
            boolean hasDigit = false, hasUppercase = false, hasSpecial = false;
            for (char c : password.toCharArray()) {
                if (Character.isUpperCase(c)) hasUppercase = true;
                if (Character.isDigit(c)) hasDigit = true;
                if (!Character.isLetterOrDigit(c)) hasSpecial = true;
            }
            return hasDigit && hasUppercase && hasSpecial;
        }

        // South African mobile number validation:
        // Must start with +27 and contain exactly nine numeric digits after it.
        public static boolean isPhoneNumberValid(String number) {
            return number != null && number.matches("^\\+27[0-9]{9}$");
        }

        // Registration workflow:
        // Ensures that username, password, and phone number all satisfy their rules.
        // Returns a feedback message indicating the first issue found, or success if all checks pass.
        public String validateAndRegisterUser(String username, String password, String phoneNumber) {
            boolean usernameIsValid = isUsernameValid(username);
            boolean passwordIsStrong = isPasswordStrong(password);
            boolean phoneIsValid = isPhoneNumberValid(phoneNumber);

            if (!usernameIsValid) {
                return "Username is not correctly formatted. Please ensure that your username contains an underscore and is no more than five characters in length.";
            } else if (!passwordIsStrong) {
                return "Password is not correctly formatted. Please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
            } else if (!phoneIsValid) {
                return "Cell phone number is incorrectly formatted or does not contain the correct international code.";
            } else {
                return "Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.\nUser registered successfully.";
            }
        }

        // Authentication process:
        // Confirms that the provided login details match the stored registration records.
        public boolean authenticate() {
            return inputtedUsername != null && inputtedPassword != null &&
                    inputtedUsername.equals(Login.getUserName()) &&
                    inputtedPassword.equals(Login.getPassword());
        }

        // Login outcome:
        // Returns a personalized greeting on success, or an error message on failure.
        public String getLoginFeedback() {
            if (authenticate()) {
                return "Welcome " + Login.getFirstName() + " " + Login.getLastName() + "! It is great to see you again.";
            } else {
                return "Username or password incorrect. Please try again.";
            }
        }

        // Capture user input for login credentials
        public void inputUsername(String username) {
            this.inputtedUsername = username;
        }

        public void inputPassword(String password) {
            this.inputtedPassword = password;
        }
    }
}
